package com.nabeeltech.androidrestphp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ProfileActivity extends AppCompatActivity {

    TextView u_name, u_email;
    Button logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        if(!ManagerSharedPreferences.getInstance(this).isLoggedIn())
        {
            finish();
            startActivity(new Intent(this, LoginActivity.class));
        }

        u_name = findViewById(R.id.text_user);
        u_email = findViewById(R.id.text_email);
        logout = findViewById(R.id.btn_logout);

        u_name.setText(ManagerSharedPreferences.getInstance(this).getUsername());
        u_email.setText(ManagerSharedPreferences.getInstance(this).getUserEmail());

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                log_out_user();
            }
        });


    }

    private void log_out_user()
    {
        ManagerSharedPreferences.getInstance(this).logout();
        finish();
        startActivity(new Intent(this, MainActivity.class));
    }
}
