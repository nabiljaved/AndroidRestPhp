package com.nabeeltech.androidrestphp;

public class Constants {

    private static final String ROOT_URI = "http://192.168.0.105/androidphp/webservices1/";

    public static final String URL_REGISTER = ROOT_URI+"registerUser.php";
    public static final String URL_LOGIN = ROOT_URI+"userLogin.php";

}
