package com.nabeeltech.androidrestphp;

import androidx.appcompat.app.AppCompatActivity;
import es.dmoral.toasty.Toasty;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.rengwuxian.materialedittext.MaterialEditText;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    MaterialEditText email_text, password_text, username_text;
    Button register;
    private ProgressDialog loadingBar;
    TextView login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //check if user is logged in already

        if(ManagerSharedPreferences.getInstance(this).isLoggedIn())
        {
            finish();
            startActivity(new Intent(this, ProfileActivity.class));
            return;
        }

        email_text = findViewById(R.id.email);
        password_text = findViewById(R.id.password);
        username_text = findViewById(R.id.username);
        register = (Button) findViewById(R.id.btn_signup);
        login = findViewById(R.id.go_to_login);
        loadingBar = new ProgressDialog(this);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createNewAccount();
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void createNewAccount()
    {


        final String email = email_text.getText().toString().trim();
        final String password = password_text.getText().toString().trim();
        final String u_name = username_text.getText().toString().trim();



        if(email.isEmpty())
        {
            email_text.setError("Email cannot be Blank");
            email_text.requestFocus();
            return;
        }


        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches())
        {
            email_text.setError("Please Enter Valid Format Email");
            email_text.requestFocus();
            return;
        }


        if(password.isEmpty())
        {
            password_text.setError("Password cannot be Blank");
            password_text.requestFocus();
            return;
        }


        if(password.length()<6 )
        {
            password_text.setError("The Password length is less then 6");
            password_text.requestFocus();
            return;
        }


        if(u_name.isEmpty())
        {
            username_text.setError("username cannot be Blank");
            username_text.requestFocus();
            return;
        }


        loadingBar.setTitle("Creating New Account");
        loadingBar.setMessage("Please wait, while we are creating your new Account...");
        loadingBar.show();
        loadingBar.setCanceledOnTouchOutside(true);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_REGISTER,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response)
                    {

                        try {
                            JSONObject jsonObject = new JSONObject(response);

                            Toasty.success(MainActivity.this, jsonObject.getString("message"), Toast.LENGTH_SHORT).show();
                            clear();
                            loadingBar.dismiss();

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error)
                    {
                        Toasty.error(MainActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                        clear();
                        loadingBar.dismiss();

                    }
                }
        ){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("email", email);
                params.put("password", password);
                params.put("username", u_name);
                return params;
            }
        };

//        RequestQueue requestQueue = Volley.newRequestQueue(this);
//        requestQueue.add(stringRequest);

        //we can implement sigleton class also
        MySingleton.getInstance(this).addToRequestQueue(stringRequest);
    }

    private void clear()
    {
        //clear fields
        email_text.setText("");
        password_text.setText("");
        username_text.setText("");
    }
}
