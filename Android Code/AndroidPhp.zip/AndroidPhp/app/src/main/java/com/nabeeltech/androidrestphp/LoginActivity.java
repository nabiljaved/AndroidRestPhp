package com.nabeeltech.androidrestphp;

import androidx.appcompat.app.AppCompatActivity;
import es.dmoral.toasty.Toasty;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.RequestFuture;
import com.android.volley.toolbox.StringRequest;
import com.rengwuxian.materialedittext.MaterialEditText;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {

    MaterialEditText password_text, username_text;
    Button login;
    private ProgressDialog loadingBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //check if user is already logedin
        if(ManagerSharedPreferences.getInstance(this).isLoggedIn())
        {
            finish();
            startActivity(new Intent(this, ProfileActivity.class));
            return;
        }

        password_text = findViewById(R.id.password);
        username_text = findViewById(R.id.username);
        login = (Button) findViewById(R.id.btn_login);
        loadingBar = new ProgressDialog(this);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                create_login();

            }
        });


    }


    private void create_login()
    {

        final String password = password_text.getText().toString().trim();
        final String u_name = username_text.getText().toString().trim();


        if(u_name.isEmpty())
        {
            username_text.setError("username cannot be Blank");
            username_text.requestFocus();
            return;
        }

        if(password.isEmpty())
        {
            password_text.setError("Password cannot be Blank");
            password_text.requestFocus();
            return;
        }


        loadingBar.setTitle("Login your account");
        loadingBar.setMessage("Please wait, while we are login your new Account...");
        loadingBar.show();
        loadingBar.setCanceledOnTouchOutside(true);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_LOGIN, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                loadingBar.dismiss();

                try {
                    JSONObject obj = new JSONObject(response);

                    if(!obj.getBoolean("error"))
                    {
                        ManagerSharedPreferences.getInstance(getApplicationContext()).userLogin(obj.getInt("id"), obj.getString("username"), obj.getString("email"));
                        sendToProfile();
                        Toasty.success(LoginActivity.this,"Successfully Loged In", Toast.LENGTH_SHORT).show();

                    }else{

                        Toasty.error(LoginActivity.this, obj.getString("message"), Toast.LENGTH_SHORT).show();
                    }

                    clear();


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }

            },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error)
                    {
                        Toasty.error(LoginActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                        clear();
                        loadingBar.dismiss();
                    }
                }

        ){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("password", password);
                params.put("username", u_name);
                return params;
            }
        };

        MySingleton.getInstance(this).addToRequestQueue(stringRequest);

    }

    private void sendToProfile()
    {
        finish();
        startActivity(new Intent(this, ProfileActivity.class));

    }


    private void clear()
    {
        //clear fields
        password_text.setText("");
        username_text.setText("");
    }


}
